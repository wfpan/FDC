import org.apache.tools.ant.Task;

public class Task1 extends Task {
}

