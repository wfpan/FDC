public class B extends C {
}

